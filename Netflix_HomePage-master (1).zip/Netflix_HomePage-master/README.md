# Netflix_HomePage
Netflix home page website using HTML and CSS.
